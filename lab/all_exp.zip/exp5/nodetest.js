var name="Mahi"

var email="mahi1120@gmail.com"

console.log("Name:"+name)
console.log("Email:"+email)

var a=10
var b=20

 var sum=a+b
console.log("sum:"+sum)
 var diff=b-a
 console.log("Difference:"+diff)

// server.mjs
// import { createServer } from 'node:http';

// const server = createServer((req, res) => {
//   res.writeHead(200, { 'Content-Type': 'text/plain' });
//   res.end('Hello World!\n');
// });

// // starts a simple http server locally on port 3000
// server.listen(3000, '127.0.0.1', () => { //0.0.0.0 broadcast 
//   console.log('Listening on 127.0.0.1:3000');
// });

// run with `node server.mjs`
//npm init -y